from classes import Slide, Photo

def get_indexes(slides:list):
	index = 0
	for slide in slides:
		slide.index = index
		index += 1

def get_lover(slide: Slide, slides:list) -> int:
	points = -1
	lover = None
	for other_slide in slides:
		if other_slide.index == slide.index:
			continue
		if points < slide.points(other_slide):
			points = slide.points(other_slide)
			lover = other_slide
	if lover is None:
		raise Exception("Lover is None")
	return lover
# n² complexity
def get_best_partners(slides:list):
	index = 0
	for slide in slides:
		if index%100 == 0:
			print("Obteniendo best_partner_of: {}".format(index), end="\r")
		for other_slide in slides:
			if slide.index == other_slide.index:
				continue
			points = slide.points(other_slide)
			if slide.best_partner_points < points:
				slide.best_partner_points = points
				slide.best_partner_index = other_slide.index
		index += 1

def get_coincidences(slides:list):
	for slide in slides:
		if slide.has_coincidence:
			continue
		other_slide = get_slide(slides=slides, index= slide.best_partner_index)
		if slide.best_partner_index == other_slide.best_partner_index:
			slide.has_coincidence = True
			other_slide.has_coincidence = True
def get_slide(slides:list, index: int)-> Slide:
	for slide in slides:
		if slide.index == index:
			return slide
	raise Exception("Slide not found")

def get_best_sort(slides:list):
	print("Obteniendo indices de las slides")
	get_indexes(slides)
	print("Obteniendo mejores compañeros")
	get_best_partners(slides)
	print("Obteniendo coincidencias")
	get_coincidences(slides)
	best_sort_aprox = list()
	best_sort_aprox.append(slides[0])
	slides.pop(0)
	last = best_sort_aprox[0]
	print("Ordenando")
	while len(slides):
		if len(slides)%100 == 0:
			print("Quedan {}.0000 slides por ordenar".format(len(slides)))
		if last.has_coincidence:
				
			next_slide = get_slide(slides=slides, index=last.best_partner_index)
			remove_index = 0
			for index, slide in enumerate(slides):
				if slide.index == next_slide.index:
					remove_index = index
					break
			best_sort_aprox.append(next_slide)
			last = next_slide
			slides.pop(remove_index)
		else:
			next_slide = get_lover(slides=slides, slide=last)
			best_sort_aprox.append(next_slide)
			last = next_slide
			remove_index = 0
			for index, slide in enumerate(slides):
				if slide.index == next_slide.index:
					remove_index = index
					break
			slides.pop(remove_index)
	return best_sort_aprox

if __name__ == "__main__":
    attempt = "b_lovely_landscapes.txt"
    solution = "b_modified_solution.txt"

    data = Slide.parse_file(attempt)

    dataV = [photo for photo in data if photo.orientation]
    dataH = [photo for photo in data if not photo.orientation]


    slides = [Slide([photo]) for photo in dataH]
    #slides.extend(dataV) #TODO
    slides_solution = get_best_sort(slides)

    Slide.parse_output(slides_solution,solution)



